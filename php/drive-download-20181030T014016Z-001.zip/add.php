<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Gesport reservas</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-datepicker.css" rel="stylesheet">
	<link href="css/style_nav.css" rel="stylesheet">
	<style>
		.content {
			margin-top: 80px;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
		<?php include("nav.php");?>
	</nav>
	<div class="container">
		<div class="content">
			<h2>Datos de la reserva &raquo; Agregar datos</h2>
			<hr />

			<?php
			if(isset($_POST['add'])){
				$idEvento	     = mysqli_real_escape_string($con,(strip_tags($_POST["idEvento"],ENT_QUOTES)));
				$nombre_actividad		     = mysqli_real_escape_string($con,(strip_tags($_POST["nombre_actividad"],ENT_QUOTES)));
				$FK_idEscenario	 = mysqli_real_escape_string($con,(strip_tags($_POST["FK_idEscenario"],ENT_QUOTES)));
				$fecha_hora_inicio 	 = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_hora_inicio"],ENT_QUOTES)));
				$descripcion	 = mysqli_real_escape_string($con,(strip_tags($_POST["descripcion"],ENT_QUOTES)));
				$FK_idEntrenador	 = mysqli_real_escape_string($con,(strip_tags($_POST["FK_idEntrenador"],ENT_QUOTES)));
				$fecha_hora_fin = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_hora_fin"],ENT_QUOTES)));
				$estado	 = mysqli_real_escape_string($con,(strip_tags($_POST["estado"],ENT_QUOTES)));
			

				$cek = mysqli_query($con, "SELECT * FROM evento WHERE idEvento='$idEvento'");
				if(mysqli_num_rows($cek) == 0){
						$insert = mysqli_query($con, "INSERT INTO evento(idEvento, nombre_actividad, FK_idEscenario, fecha_hora_inicio, descripcion, FK_idEntrenador, fecha_hora_fin, estado)
															VALUES('$idEvento','$nombre_actividad', '$FK_idEscenario', '$fecha_hora_inicio', '$descripcion', '$FK_idEntrenador', '$fecha_hora_fin', '$estado')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho! Los datos han sido guardados con éxito.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error. No se pudo guardar los datos !</div>';
						}
					 
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error. código exite!</div>';
				}
			}
			?>

			<form class="form-horizontal" action="" method="post">
				<div class="form-group">
					<label class="col-sm-3 control-label">Id Evento</label>
					<div class="col-sm-2">
						<input type="text" name="idEvento" class="form-control" placeholder="Código" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Nombre actividad</label>
					<div class="col-sm-4">
						<input type="text" name="nombre_actividad" class="form-control" placeholder="Nombre de la actividad" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Id Escenario</label>
					<div class="col-sm-4">
						<input type="text" name="FK_idEscenario" class="form-control" placeholder="Código del escenario" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Fecha inicio</label>
					<div class="col-sm-4">
						<input type="text" name="fecha_hora_inicio" class="input-group date form-control" date="" data-date-format="dd-mm-yyyy" placeholder="00-00-0000" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Descripción</label>
					<div class="col-sm-3">
						<textarea name="descripcion" class="form-control" placeholder="Descripción del evento"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Id Entrenador</label>
					<div class="col-sm-3">
						<input type="text" name="FK_idEntrenador" class="form-control" placeholder="Identificación del entrenador" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Fecha fin</label>
					<div class="col-sm-3">
						<input type="text" name="fecha_hora_fin" class="input-group date form-control" date="" data-date-format="dd-mm-yyyy" placeholder="00-00-0000" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Estado</label>
					<div class="col-sm-3">
						<select name="estado" class="form-control">
							<option value=""> ----- </option>
                           <option value="1">Aprobado</option>
							<option value="2">Cancelado</option>
							
							 <option value="3">En espera</option>
						</select>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="add" class="btn btn-sm btn-primary" value="Guardar datos">
						<a href="index.php" class="btn btn-sm btn-danger">Cancelar</a>
					</div>
				</div>
			</form>
		</div>
	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
	$('.date').datepicker({
		format: 'dd-mm-yyyy',
	})
	</script>
</body>
</html>
