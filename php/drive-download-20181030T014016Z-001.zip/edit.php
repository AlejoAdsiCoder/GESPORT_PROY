<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Reserva</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-datepicker.css" rel="stylesheet">
	<link href="css/style_nav.css" rel="stylesheet">
	<style>
		.content {
			margin-top: 80px;
		}
	</style>	
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
		<?php include("nav.php");?>
	</nav>
	<div class="container">
		<div class="content">
			<h2>Datos de la reserva &raquo; Editar datos</h2>
			<hr />
			
			<?php
			// escaping, additionally removing everything that could be (html/javascript-) code
			$nik = mysqli_real_escape_string($con,(strip_tags($_GET["nik"],ENT_QUOTES)));
			$sql = mysqli_query($con, "SELECT * FROM evento WHERE idEvento='$nik'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: index.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			if(isset($_POST['save'])){
				$idEvento	     = mysqli_real_escape_string($con,(strip_tags($_POST["idEvento"],ENT_QUOTES)));//Escanpando caracteres 
				$nombre_actividad		     = mysqli_real_escape_string($con,(strip_tags($_POST["nombre_actividad"],ENT_QUOTES)));//Escanpando caracteres 
				$FK_idEscenario	 = mysqli_real_escape_string($con,(strip_tags($_POST["FK_idEscenario"],ENT_QUOTES)));//Escanpando caracteres 
				$fecha_hora_inicio 	 = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_hora_inicio"],ENT_QUOTES)));//Escanpando caracteres 
				$descripcion	 = mysqli_real_escape_string($con,(strip_tags($_POST["descripcion"],ENT_QUOTES)));//Escanpando caracteres 
				$FK_idEntrenador	 = mysqli_real_escape_string($con,(strip_tags($_POST["FK_idEntrenador"],ENT_QUOTES)));//Escanpando caracteres 
				$fecha_hora_fin = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_hora_fin"],ENT_QUOTES)));//Escanpando caracteres 
				$estado	 = mysqli_real_escape_string($con,(strip_tags($_POST["$estado"],ENT_QUOTES)));//Escanpando caracteres 		
							
				$update = mysqli_query($con, "UPDATE evento SET nombre_actividad='$nombre_actividad', FK_idEscenario='$FK_idEscenario', fecha_hora_inicio='$fecha_hora_inicio', descripcion='$descripcion', FK_idEntrenador='$FK_idEntrenador', fecha_hora_fin='$fecha_hora_fin', estado='$estado' WHERE idEvento='$nik'") or die(mysqli_error());
				if($update){
					header("Location: edit.php?nik=".$nik."&pesan=sukses");
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo guardar los datos.</div>';
				}
			}
			
			if(isset($_GET['pesan']) == 'sukses'){
				echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Los datos han sido guardados con éxito.</div>';
			}
			?>
			<form class="form-horizontal" action="" method="post">
				<div class="form-group">
					<label class="col-sm-3 control-label">Id evento</label>
					<div class="col-sm-2">
						<input type="text" name="idEvento" value="<?php echo $row ['idEvento']; ?>" class="form-control" placeholder="NIK" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Nombre actividad</label>
					<div class="col-sm-4">
						<input type="text" name="nombre_actividad" value="<?php echo $row ['nombre_actividad']; ?>" class="form-control" placeholder="Nombre de la actividad" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Id Escenario</label>
					<div class="col-sm-4">
						<input type="text" name="FK_idEscenario" value="<?php echo $row ['FK_idEscenario']; ?>" class="form-control" placeholder="Código del escenario" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Fecha Inicio</label>
					<div class="col-sm-4">
						<input type="text" name="fecha_hora_inicio" value="<?php echo $row ['fecha_hora_inicio']; ?>" class="input-group date form-control" date="" data-date-format="yyyy-mm-dd" placeholder="0000-00-00" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Descripción</label>
					<div class="col-sm-3">
						<textarea name="descripcion" class="form-control" placeholder="Descripcion"><?php echo $row ['descripcion']; ?></textarea>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Id Entrenador</label>
					<div class="col-sm-3">
						<input type="text" name="FK_idEntrenador" value="<?php echo $row ['FK_idEntrenador']; ?>" class="form-control" placeholder="Identificación del entrenador" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Fecha fin</label>
					<div class="col-sm-3">
						
						<input type="text" name="fecha_hora_fin" value="<?php echo $row ['fecha_hora_fin']; ?>" class="input-group date form-control" date="" data-date-format="yyyy-mm-dd" placeholder="0000-00-00" required>
					</div>
                    
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Estado</label>
					<div class="col-sm-3">
						<select name="estado" class="form-control">
							<option value="">- Selecciona estado -</option>
                            <option value="1" <?php if ($row ['estado']==1){echo "selected";} ?>>Aprobado</option>
							<option value="2" <?php if ($row ['estado']==2){echo "selected";} ?>>Cancelado</option>
							<option value="3" <?php if ($row ['estado']==3){echo "selected";} ?>>En espera</option>
						</select> 
					</div>
                   
                </div>
			
				<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="save" class="btn btn-sm btn-primary" value="Guardar datos">
						<a href="index.php" class="btn btn-sm btn-danger">Cancelar</a>
					</div>
				</div>
			</form>
		</div>
	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
	$('.date').datepicker({
		format: 'dd-mm-yyyy',
	})
	</script>
</body>
</html>